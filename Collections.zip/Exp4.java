import java.time.LocalDate;
import java.util.LinkedList;

public class Exp4 {
    public static void main(String[] args) {

        //LocalDate to represent dates of birth
        LinkedList<LocalDate> d = new LinkedList<>();

        // Adding sample dates of birth
        d.add(LocalDate.of(2000, 12, 23));
        d.add(LocalDate.of(2001, 12, 23));
        d.add(LocalDate.of(1996, 2, 29)); // Leap year date
        d.add(LocalDate.of(1987, 7, 15));

        // Iterate through the dates in reverse order
        for (int i = d.size() - 1; i >= 0; i--) 
        {
            LocalDate date = d.get(i);
            String leapYearMessage;
            if(isLeapYear(date.getYear()))
            {
                    leapYearMessage= "it was a leap year";
            }  
            else{
                    leapYearMessage="it was not a leap year";
            }
            System.out.println("Your date of birth is " + formatDate(date) + " and " + leapYearMessage);
        }
    }

    // Method to check if a year is a leap year
    private static boolean isLeapYear(int year) 
    {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

    // Method to format the date as DD-MM-YYYY
    private static String formatDate(LocalDate date) {
        int day = date.getDayOfMonth();
        int month = date.getMonthValue();
        int year = date.getYear();
        return String.format("%02d-%02d-%04d", day, month, year);
    }
}
