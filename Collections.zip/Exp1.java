import  java.util.*;


enum Gender {
    MALE, FEMALE, OTHER
}


class contact
{
    private Long PhoneNumer;
	private String Name;
	private String Email;
	private Gender gender;

    public contact(Long PhoneNumer, String Name, String Email, Gender gender)
    {
        this.PhoneNumer=PhoneNumer;
        this.Name=Name;
        this.Email=Email;
        this.gender=gender;
    }

    public Long getPhoneNumber() {
        return PhoneNumer;
    }

    public String getName() {
        return Name;
    }
    public String getEmail() {
        return Email;
    }
    public Gender getGender() {
        return gender;
    }


    //the toString method is overridden to provide a formatted string representation of the Contact object
    public String toString() {
        return "Contact{" +
                "PhoneNumber=" + PhoneNumer +
                ", Name='" + Name + '\'' +
                ", Email='" + Email + '\'' +
                ", Gender=" + gender +
                '}';
    }

}
class Exp1
{
    public static void main(String[] args)
    {

        //ReverseOrder for descending order of phonenumber
        TreeMap<Long,contact> t=new TreeMap<>(Collections.reverseOrder());


        //put L after number as it long
        t.put(9325125032L,new contact(9325125032L,"Pratiksha","Kalokhepratiksha5050@gmail.com",Gender.FEMALE));
        t.put(9172625151L,new contact(9172625151L,"Ranjeet","Ranjeetkalokhe1234@gmail.com",Gender.MALE));
        
        
        System.out.println("Size of TreeMap"+t.size());


        //a.Fetch all the Values
        System.out.println("All Keys:");
        for (Long key : t.keySet()) {
            System.out.println(key);
        }
        System.out.println();

        // b. Fetch all the values and print them
        System.out.println("All Values:");
        for (contact contact : t.values()) {
            System.out.println(contact);
        }
        System.out.println();

        // c. Print all key-value pairs
        System.out.println("All Key-Value Pairs:");
        for (Map.Entry<Long, contact> entry :t.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
    }
}

