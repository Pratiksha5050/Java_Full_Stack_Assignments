import java.util.*;


class Exp2
{
    public static void main(String[] args)
    {
        HashSet<String> p = new HashSet<>();
        p.add("Milk");
        p.add("Sugar");
        p.add("Salt");
        p.add("Cheese");
        

        System.out.println("All Products :");
        Iterator<String> it=p.iterator();
        while(it.hasNext())
        {
            System.out.println(it.next());
        }
        System.out.println();

        System.out.println("Let's Try to add Duplicate ");
        p.add("Milk");
        System.out.println();

        System.out.println("After adding duplicate value as milk :");
        Iterator<String> it2=p.iterator();
        while(it2.hasNext())
        {
            System.out.println(it2.next());
        }

    }
}