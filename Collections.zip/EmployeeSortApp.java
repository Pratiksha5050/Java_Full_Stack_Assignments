import java.util.Comparator;
import java.util.Scanner;
import java.util.TreeSet;

class Employee {
    private int id;
    private String name;
    private String department;
    private double salary;

    public Employee(int id, String name, String department, double salary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public double getSalary() {
        return salary;
    }

   
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", department='" + department + '\'' +
                ", salary=" + salary +
                '}';
    }
}

public class EmployeeSortApp {
    public static void main(String[] args) {
        TreeSet<Employee> employeeTreeSet = new TreeSet<>(Comparator.comparing(Employee::getId));

        // Adding 10 Employee objects to the TreeSet
        employeeTreeSet.add(new Employee(10, "Zen", "HR", 5000));
        employeeTreeSet.add(new Employee(7, "kapil", "IT", 6000));
        employeeTreeSet.add(new Employee(8, "Pratiksha", "Sales", 5500));
        employeeTreeSet.add(new Employee(4, "Bhavita", "Finance", 7000));
        employeeTreeSet.add(new Employee(6, "Shree", "Marketing", 4500));
        employeeTreeSet.add(new Employee(5, "Krishnraj", "HR", 5200));
        employeeTreeSet.add(new Employee(2, "Sairaj", "IT", 6500));
        employeeTreeSet.add(new Employee(3, "Kunal", "Sales", 5700));
        employeeTreeSet.add(new Employee(9, "Amita", "Finance", 7200));
        employeeTreeSet.add(new Employee(1, "Ankita", "Marketing", 4800));

        // Getting user's choice
        System.out.println("Run Application:");
        System.out.println("a) ID");
        System.out.println("b) Name");
        System.out.println("c) Department");
        System.out.println("d) Salary");
        System.out.print("Your choice: ");

        Scanner s = new Scanner(System.in);
        String choice = s.nextLine().trim().toLowerCase();

        switch (choice) {
            case "a":
                //forEach Method iterate the elements
                //tl.forEach(System.out::println)

                //The Comparator.comparing method is a static method in the Comparator interface that 
                //provides a way to create a Comparator based on a particular key extraction function.
                employeeTreeSet.stream().sorted(Comparator.comparing(Employee::getId)).forEach(System.out::println);
                break;
            case "b":
                employeeTreeSet.stream().sorted(Comparator.comparing(Employee::getName)).forEach(System.out::println);
                break;
            case "c":
                employeeTreeSet.stream().sorted(Comparator.comparing(Employee::getDepartment)).forEach(System.out::println);
                break;
            case "d":
                employeeTreeSet.stream().sorted(Comparator.comparing(Employee::getSalary)).forEach(System.out::println);
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }
}
