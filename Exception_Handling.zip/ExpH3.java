// Write an application to perform withdraw functionality on a SavingAccount object. Point to 
// note: 
// a. Raise InsufficientBalanceException if you are trying to withdraw more than balance 
// or when you balance is zero. E.g. if you balance is 2000 and if you are trying to 
// withdraw 2100 or if you balance is 0 and you are trying to withdraw positive value. 
// b. Raise IllegalBankTransactionException if you are trying to withdraw a negative value 
// from your balance. E.g. if you try to withdraw a negative value savingAcc.withdraw(-
// 1000); 
// Note: SavingAccount 
//  |-- long id 
//  |-- double balance 
//  |--double withdraw(double amount) 
//  |--double deposit(double amount)
class InsufficientBalanceException extends Exception {
    public InsufficientBalanceException(String message) {
        super(message);
    }
}

class IllegalBankTransactionException extends Exception {
    public IllegalBankTransactionException(String message) {
        super(message);
    }
} 

class SavingAccount
{
    private long id;
    private double balance;

    public SavingAccount(long id,double balance)
    {
        this.id=id;
        this.balance=balance;
    }
    public double withdraw(double amount) throws InsufficientBalanceException,IllegalBankTransactionException
    {
        if(amount<0)
        {
            throw new IllegalBankTransactionException("Cannot withdrow a negative number");
        }
        else if(balance==0 || amount>balance)
        {
            throw new InsufficientBalanceException("Insufficient balance for transaction");
        }
        else
        {
            balance-=amount;
            return balance;
        }
    }

    public double getBalance() {
        return balance;
    }

    public double deposit(double amount) throws IllegalBankTransactionException
    {
        if (amount < 0) 
        {
            throw new IllegalBankTransactionException("Cannot deposit a negative amount");
        }

        balance += amount;
        return balance;
    }
}

public class ExpH3
{
    public static void main(String[] args)
    {
        SavingAccount sc=new SavingAccount(1234,2000);

        try
        {
            System.out.println("Current balance is : "+sc.withdraw(2100));
        }
        catch(InsufficientBalanceException | IllegalBankTransactionException e)
        {
            System.err.println(e.toString());
        }


        try
        {
            System.out.println("Current balance is : "+sc.withdraw(-1000));
        }
        catch(InsufficientBalanceException | IllegalBankTransactionException e)
        {
            System.err.println(e.toString());
        }


        try
        {
            System.out.println("Current balance is : "+sc.withdraw(1000));
        }
        catch(InsufficientBalanceException | IllegalBankTransactionException e)
        {
            System.err.println(e.toString());
        }

        try
        {
            System.out.println("Current balance is : "+sc.deposit(1000));
        }
        catch(IllegalBankTransactionException e)
        {
            System.err.println(e.toString());
        }

    }
}