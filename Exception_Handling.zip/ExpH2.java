
//handle ArithmeticException by raising UnsupportedOperationException as a solution.
import java.util.Scanner;

class ExpH2
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 1st Number :");
        int a=sc.nextInt();
        System.out.println("Enter 2nd Number");
        int b=sc.nextInt();

        try
        {
            if(b==0)
            {
                throw new UnsupportedOperationException("Divide by 0 is not allow");
            }
            int result=a/b;
            System.out.println("Division of 2 Numbers:"+result);
        }
        catch(UnsupportedOperationException e)
        {
            System.out.println("Divide by 0 gives error "+e.toString());
        }
    }
}